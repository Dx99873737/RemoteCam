import { useEffect, useRef, useState } from "react";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signOut, type User
} from "firebase/auth";
import {
  addDoc, collection, deleteDoc, doc, getDoc, onSnapshot, serverTimestamp, setDoc, updateDoc
} from "firebase/firestore";
import { auth, db, firebaseConfigured } from "./firebase";
import { Camera, CameraOff, Copy, Link2, LogOut, Mic, MicOff, PhoneOff, ShieldCheck, Video } from "lucide-react";

type Mode = "idle" | "host" | "guest";
const rtcConfig: RTCConfiguration = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [register, setRegister] = useState(false);
  const [roomCode, setRoomCode] = useState("");
  const [mode, setMode] = useState<Mode>("idle");
  const [status, setStatus] = useState("Sign in to start a private session.");
  const [busy, setBusy] = useState(false);
  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [remoteReady, setRemoteReady] = useState(false);
  const localVideo = useRef<HTMLVideoElement>(null);
  const remoteVideo = useRef<HTMLVideoElement>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStream = useRef<MediaStream | null>(null);
  const stopListeners = useRef<Array<() => void>>([]);
  const sessionRef = useRef<string | null>(null);

  useEffect(() => onAuthStateChanged(auth, setUser), []);
  useEffect(() => () => cleanup(), []);

  function cleanup() {
    stopListeners.current.forEach((stop) => stop());
    stopListeners.current = [];
    pcRef.current?.close(); pcRef.current = null;
    localStream.current?.getTracks().forEach((track) => track.stop()); localStream.current = null;
    if (localVideo.current) localVideo.current.srcObject = null;
    if (remoteVideo.current) remoteVideo.current.srcObject = null;
    setRemoteReady(false);
  }

  async function getMedia() {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error("Camera/microphone need HTTPS and a supported browser.");
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
    localStream.current = stream;
    if (localVideo.current) localVideo.current.srcObject = stream;
    return stream;
  }

  function setupPeer(sessionId: string, role: "caller" | "callee", stream: MediaStream) {
    const pc = new RTCPeerConnection(rtcConfig);
    pcRef.current = pc;
    stream.getTracks().forEach((track) => pc.addTrack(track, stream));
    pc.ontrack = (event) => {
      if (remoteVideo.current) remoteVideo.current.srcObject = event.streams[0];
      setRemoteReady(true);
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "connected") setStatus("Connected securely peer-to-peer.");
      if (["failed", "disconnected"].includes(pc.connectionState)) setStatus("Connection interrupted. Check both internet connections.");
    };
    const outgoing = collection(db, "sessions", sessionId, role === "caller" ? "callerCandidates" : "calleeCandidates");
    const incoming = collection(db, "sessions", sessionId, role === "caller" ? "calleeCandidates" : "callerCandidates");
    pc.onicecandidate = async (event) => {
      if (event.candidate) await addDoc(outgoing, event.candidate.toJSON());
    };
    const stop = onSnapshot(incoming, (snapshot) => {
      snapshot.docChanges().forEach(async (change) => {
        if (change.type === "added") {
          try { await pc.addIceCandidate(new RTCIceCandidate(change.doc.data())); } catch { /* candidate may arrive after close */ }
        }
      });
    });
    stopListeners.current.push(stop);
    return pc;
  }

  async function createRoom() {
    if (!user) return;
    setBusy(true);
    try {
      cleanup();
      setStatus("Allow camera and microphone when your phone asks.");
      const stream = await getMedia();
      let code = "";
      let ref;
      // Retry a few times to avoid a six-digit room-code collision.
      for (let attempt = 0; attempt < 5; attempt++) {
        code = String(Math.floor(100000 + Math.random() * 900000));
        ref = doc(db, "sessions", code);
        const existing = await getDoc(ref);
        if (!existing.exists()) break;
        ref = undefined;
      }
      if (!ref) throw new Error("Could not create a room. Please try again.");
      sessionRef.current = code;
      // Create the parent session before starting ICE gathering so candidate writes
      // always have an authorized parent document.
      await setDoc(ref, { ownerUid: user.uid, guestUid: null, createdAt: serverTimestamp(), status: "waiting" });
      const pc = setupPeer(code, "caller", stream);
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await updateDoc(ref, { offer: { type: offer.type, sdp: offer.sdp } });
      const stop = onSnapshot(ref, async (snap) => {
        const data = snap.data();
        if (data?.answer && pc.signalingState === "have-local-offer") {
          await pc.setRemoteDescription(new RTCSessionDescription(data.answer));
          setStatus("Answer received. Connecting…");
        }
      });
      stopListeners.current.push(stop);
      setRoomCode(code); setMode("host"); setStatus("Share this six-digit code with the other person.");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Could not create session.");
      cleanup();
    } finally { setBusy(false); }
  }

  async function joinRoom() {
    if (!user || !/^\d{6}$/.test(roomCode)) { setStatus("Enter the six-digit room code."); return; }
    setBusy(true);
    try {
      cleanup();
      setStatus("Allow camera and microphone when your phone asks.");
      const stream = await getMedia();
      const ref = doc(db, "sessions", roomCode);
      await updateDoc(ref, { guestUid: user.uid });
      const snap = await getDoc(ref);
      if (!snap.exists() || !snap.data().offer) throw new Error("Room not found or offer is missing.");
      sessionRef.current = roomCode;
      const pc = setupPeer(roomCode, "callee", stream);
      await pc.setRemoteDescription(new RTCSessionDescription(snap.data().offer));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await updateDoc(ref, { answer: { type: answer.type, sdp: answer.sdp }, status: "connecting" });
      setMode("guest"); setStatus("Joining room…");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Could not join session.");
      cleanup();
    } finally { setBusy(false); }
  }

  async function endCall() {
    const code = sessionRef.current;
    cleanup(); setMode("idle"); setRoomCode(""); sessionRef.current = null;
    if (code && user) {
      try {
        const ref = doc(db, "sessions", code);
        const snap = await getDoc(ref);
        if (snap.exists() && snap.data().ownerUid === user.uid) await deleteDoc(ref);
      } catch { /* session may already have expired or access ended */ }
    }
    setStatus("Session ended. Camera and microphone are off.");
  }

  function toggleTrack(kind: "video" | "audio") {
    const track = localStream.current?.getTracks().find((item) => item.kind === kind);
    if (track) {
      track.enabled = !track.enabled;
      if (kind === "video") setCameraOn(track.enabled);
      else setMicOn(track.enabled);
    }
  }

  async function authenticate(event: React.FormEvent) {
    event.preventDefault(); setBusy(true);
    try {
      if (register) await createUserWithEmailAndPassword(auth, email.trim(), password);
      else await signInWithEmailAndPassword(auth, email.trim(), password);
      setStatus("Signed in. You can create or join a room.");
    } catch (error) { setStatus(error instanceof Error ? error.message : "Sign-in failed."); }
    finally { setBusy(false); }
  }

  return <main className="shell">
    <header><div className="brand"><div className="logo"><Video size={22}/></div><div><b>RemoteCam</b><small>Private live connection</small></div></div>
      {user && <button className="iconBtn" onClick={() => signOut(auth)} aria-label="Sign out"><LogOut size={18}/></button>}
    </header>
    <section className="hero"><div className="eyebrow"><ShieldCheck size={15}/> CONSENT-BASED CONNECTION</div>
      <h1>See and hear.<br/><span>Only with permission.</span></h1>
      <p>Connect two phones with live camera and voice. Both people must open RemoteCam and approve camera and microphone access.</p>
    </section>

    {!firebaseConfigured && <div className="notice warning">Firebase setup is not connected yet. Add your Firebase web app settings to the <code>.env</code> file before signing in.</div>}

    {!user ? <section className="panel authPanel"><h2>{register ? "Create your account" : "Welcome back"}</h2>
      <form onSubmit={authenticate}><label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="you@example.com"/></label>
      <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} minLength={6} required placeholder="At least 6 characters"/></label>
      <button className="primary" disabled={busy || !firebaseConfigured}>{busy ? "Please wait…" : register ? "Create account" : "Sign in"}</button></form>
      <button className="textBtn" onClick={()=>setRegister(!register)}>{register ? "Already have an account? Sign in" : "New here? Create an account"}</button>
    </section> : <>
      <section className="panel actions"><div className="sectionHead"><div><h2>Your connection</h2><p>Create a room or join someone else's room.</p></div><span className="onlineDot">● Ready</span></div>
        {mode === "idle" ? <><button className="primary" disabled={busy} onClick={createRoom}><Link2 size={18}/> Create private room</button>
          <div className="or"><span/> OR <span/></div>
          <label>Six-digit room code<input inputMode="numeric" maxLength={6} value={roomCode} onChange={e=>setRoomCode(e.target.value.replace(/\D/g,""))} placeholder="123456"/></label>
          <button className="secondary" disabled={busy} onClick={joinRoom}>Join room</button></> :
          <><div className="codeBox"><small>ROOM CODE — SHARE WITH THE OTHER PERSON</small><strong>{roomCode}</strong><button className="copyBtn" onClick={()=>navigator.clipboard?.writeText(roomCode)}><Copy size={15}/> Copy code</button></div>
          <div className="videoGrid"><div className="videoTile"><video ref={localVideo} autoPlay muted playsInline/><span>You · Camera preview</span></div><div className="videoTile remote"><video ref={remoteVideo} autoPlay playsInline/><span>{remoteReady ? "Connected device" : "Waiting for other phone…"}</span></div></div>
          <div className="controls"><button className={cameraOn?"control":"control off"} onClick={()=>toggleTrack("video")}>{cameraOn?<Camera/>:<CameraOff/>}{cameraOn?"Camera on":"Camera off"}</button><button className={micOn?"control":"control off"} onClick={()=>toggleTrack("audio")}>{micOn?<Mic/>:<MicOff/>}{micOn?"Mic on":"Mic off"}</button><button className="hangup" onClick={endCall}><PhoneOff/> End</button></div></>}
      </section>
    </>}
    <div className="status" role="status">{status}</div>
    <footer><ShieldCheck size={15}/> Camera and microphone start only after you tap Create or Join. End the session to stop both.</footer>
  </main>;
}