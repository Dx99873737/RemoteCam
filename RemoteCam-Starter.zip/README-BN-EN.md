# RemoteCam — starter project

This is a mobile-friendly web app (PWA-ready foundation) for a consent-based, two-person live camera + voice connection. It can run in Android Chrome and iPhone Safari when hosted over HTTPS.

## Included
- Email/password Firebase Authentication
- Create a six-digit room and join from another signed-in device
- WebRTC audio/video with explicit camera/microphone permission prompts
- Camera and microphone on/off controls and End button
- Firestore signaling rules that restrict session access to the two signed-in participants

## Before it can run
1. In Firebase Console, open Project settings → Your apps → Web app (`</>`). Register a web app if one does not exist.
2. Copy its Firebase config values into a new file named `.env` (copy `.env.example` and replace every value).
3. In Firebase Authentication → Sign-in method, enable Email/Password.
4. Create the Firestore database. Deploy `firestore.rules` using Firebase CLI (`firebase deploy --only firestore:rules`) or paste the rules into Firestore → Rules and Publish.
5. Install Node.js on a computer or use a cloud development environment:
   - `npm install`
   - `npm run dev` for testing
   - `npm run build` for production build
6. Deploy the `dist` folder to Firebase Hosting (`firebase deploy --only hosting`) after `firebase init hosting` has been configured.

## Important limitations
- This is a web app starter, not a published native iOS/Android app.
- Both people must open the app, sign in, and explicitly allow camera/microphone access. It cannot secretly turn on either device's camera or microphone.
- The included WebRTC setup uses a public STUN server only. Some mobile networks/firewalls require a TURN relay server for reliable connectivity; add a private TURN service before relying on this in production.
- The six-digit room code is a convenience, not a substitute for sharing it privately. Session docs should be deleted/expired server-side in a production release.
- Test on two separate devices over HTTPS. Browser permission prompts and autoplay behavior vary by device.
- Firestore rules are a starting point and should be security-reviewed before production. Do not make the database public or use test-mode rules.
